import type { Metadata, Viewport } from "next";
import "@fontsource-variable/inter";
import "./globals.css";
import { Toaster } from "sonner";
import { getSettings } from "@/lib/services/settings";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings().catch(() => null);
  return {
    title: { default: s?.systemName ?? "Device Inventory", template: `%s · ${s?.systemName ?? "Device Inventory"}` },
    description: `${s?.organizationName ?? "MPL"} asset inventory & equipment management`,
  };
}

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0f1b2d" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="min-h-dvh antialiased">
        {children}
        <Toaster position="top-right" richColors closeButton toastOptions={{ className: "text-[13px]" }} />
      </body>
    </html>
  );
}
